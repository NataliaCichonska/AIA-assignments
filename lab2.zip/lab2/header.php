<!doctype html>
<html>

<head>
  <title>FIlmweb</title>
  <meta name="description" content="Film info servide">
  <meta name="keywords" content="film">
  <meta name="robots" content="noindex">
  <link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="styles.css">
</head>